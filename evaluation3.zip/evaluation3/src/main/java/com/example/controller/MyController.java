package com.example.controller;

import com.example.entity.FIR;
import com.example.entity.User;
import com.example.service.Service_FIR;
import com.example.service.Service_User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/masaifir/user/")
public class MyController {

    @Autowired
    Service_FIR service;
    @Autowired
    Service_User service_user;

    @PostMapping("/register")
    public User createUser(@RequestBody User user) {
        return service_user.createUser(user);
    }

    @PostMapping("/login")
    public User createUse(@RequestBody User user) {
        return service_user.createUser(user);
    }

    @GetMapping("{userId}/fir/")
    public User getUserbyId(@PathVariable int u_id) {
        return service_user.getUserbyId(u_id);
    }

    @PostMapping("/fir")
    public FIR createfir(@RequestBody FIR fir) {
        return service.createFir(fir);
    }
}


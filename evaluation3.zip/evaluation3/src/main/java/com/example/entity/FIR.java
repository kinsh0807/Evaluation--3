package com.example.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;


@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data

public class FIR {

    @Id
    @GeneratedValue
    private int f_id;
    @Pattern(regexp = "^[a-zA-Z]{6,12}$",
            message = "Please Enter Valid Alphabets")
    private String firstName;
    @Pattern(regexp = "^[a-zA-Z]{6,12}$",
            message = "Please Enter Valid Alphabets")
    private String lastName;
    private String mobileNumber;
    private String address;
    private int age;
    private String gender;
    @Pattern(regexp = "^((?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9])){6,12}$", message ="Enter Correct Password" )
    private String password;


}

package com.example.exceptions;

public class InvalidException extends RuntimeException{

	public InvalidException() {}
	
	public InvalidException(String msg) {
		super(msg);
	}
}

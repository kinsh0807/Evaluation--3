package com.example.repository;

import com.example.entity.FIR;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FIR_Repo extends JpaRepository<FIR,Integer> {

}

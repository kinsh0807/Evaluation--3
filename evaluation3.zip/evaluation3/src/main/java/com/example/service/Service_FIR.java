package com.example.service;

import com.example.entity.FIR;
import org.springframework.stereotype.Service;

@Service
public interface Service_FIR {

    FIR createFir(FIR fir);
}

package com.example.service;

import com.example.entity.User;
import org.springframework.stereotype.Service;

@Service
public interface Service_User {


    User createUser(User user);

    User getUserbyId(int u_id);
}
